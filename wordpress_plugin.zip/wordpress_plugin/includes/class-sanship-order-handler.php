<?php

add_action('woocommerce_order_status_completed', function($order_id) {
    $order = wc_get_order($order_id);
    if (!$order) return;

    $body = [
        'name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
        'order_id' => $order->get_id(),
        'amount' => $order->get_total()
    ];

    $response = wp_remote_post('https://reqres.in/api/users', [
        'headers' => ['Content-Type' => 'application/json'],
        'body' => wp_json_encode($body)
    ]);

    if (!is_wp_error($response)) {
        $result = json_decode(wp_remote_retrieve_body($response), true);
        $tracking_number = $result['id'] ?? uniqid('track_');
        $order->update_meta_data('_san_tracking_number', $tracking_number);
        $order->save();
    }
});

// Admin view
add_action('woocommerce_admin_order_data_after_shipping_address', function($order) {
    $tracking = $order->get_meta('_san_tracking_number');
    if ($tracking) {
        echo '<p><strong>' . __('SanShip Tracking #', 'sanship') . ':</strong> ';
        echo '<a href="https://tracking.example.com/' . esc_attr($tracking) . '" target="_blank">' . esc_html($tracking) . '</a></p>';
    }
});

// Customer view
function show_sanship_tracking($order_id) {
    $order = wc_get_order($order_id);
    if (!$order) return;

    $tracking = $order->get_meta('_san_tracking_number');
    if ($tracking) {
        echo '<p><strong>' . __('SanShip Tracking #', 'sanship') . ':</strong> ';
        echo '<a href="https://tracking.example.com/' . esc_attr($tracking) . '" target="_blank">' . esc_html($tracking) . '</a></p>';
    }
}

add_action('woocommerce_thankyou', 'show_sanship_tracking', 20);
add_action('woocommerce_view_order', 'show_sanship_tracking', 20);
