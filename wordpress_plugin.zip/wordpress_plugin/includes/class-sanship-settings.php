<?php

add_filter('woocommerce_get_sections_integration', function($sections) {
    $sections['sanship'] = __('SanShip Express', 'sanship');
    return $sections;
});

add_filter('woocommerce_get_settings_integration', function($settings, $section) {
    if ($section == 'sanship') {
        return [
            [
                'name' => __('SanShip API Settings', 'sanship'),
                'type' => 'title',
                'id' => 'sanship_settings'
            ],
            [
                'name' => __('Client ID', 'sanship'),
                'type' => 'text',
                'id' => 'sanship_client_id'
            ],
            [
                'name' => __('Client Secret', 'sanship'),
                'type' => 'password',
                'id' => 'sanship_client_secret'
            ],
            [
                'name' => __('Mode', 'sanship'),
                'type' => 'select',
                'id' => 'sanship_mode',
                'options' => [
                    'sandbox' => __('Sandbox', 'sanship'),
                    'production' => __('Production', 'sanship')
                ]
            ],
            ['type' => 'sectionend', 'id' => 'sanship_settings']
        ];
    }
    return $settings;
}, 10, 2);
