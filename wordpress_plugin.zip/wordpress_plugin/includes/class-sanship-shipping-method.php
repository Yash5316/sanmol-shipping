<?php

if (!defined('ABSPATH')) exit;

class WC_Shipping_SanShip extends WC_Shipping_Method {

    public function __construct() {
        $this->id = 'san_ship';
        $this->method_title = __('SanShip Express', 'sanship');
        $this->method_description = __('Shipping via SanShip API (mocked)', 'sanship');
        $this->enabled = "yes";
        $this->title = "SanShip Express";
        $this->init();
    }

    public function init() {
        $this->init_form_fields();
        $this->init_settings();
        add_action('woocommerce_update_options_shipping_' . $this->id, [$this, 'process_admin_options']);
    }

    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title' => __('Enable', 'sanship'),
                'type' => 'checkbox',
                'default' => 'yes'
            ]
        ];
    }

    public function calculate_shipping($package = []) {
        $rate = [
            'id' => $this->id,
            'label' => $this->title,
            'cost' => 10,
            'calc_tax' => 'per_order'
        ];
        $this->add_rate($rate);
    }
}
