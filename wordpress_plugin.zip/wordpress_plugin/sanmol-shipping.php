<?php
/**
 * Plugin Name: SanShip Express for WooCommerce
 * Description: Adds a custom shipping method using dummy API.
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: sanship
 */

if (!defined('ABSPATH')) exit;

define('SANSHIP_VERSION', '1.0.0');
define('SANSHIP_PLUGIN_PATH', plugin_dir_path(__FILE__));

function sanship_init_plugin() {
    // Load only if WooCommerce is active
    if (class_exists('WC_Shipping_Method')) {
        require_once SANSHIP_PLUGIN_PATH . 'includes/class-sanship-shipping-method.php';

        add_filter('woocommerce_shipping_methods', function($methods) {
            $methods['san_ship'] = 'WC_Shipping_SanShip';
            return $methods;
        });
    }

    // Load other plugin parts
    require_once SANSHIP_PLUGIN_PATH . 'includes/class-sanship-settings.php';
    require_once SANSHIP_PLUGIN_PATH . 'includes/class-sanship-order-handler.php';
}
add_action('woocommerce_loaded', 'sanship_init_plugin');

// Activation/uninstall hooks (optional)
register_activation_hook(__FILE__, 'sanship_activate');
register_uninstall_hook(__FILE__, 'sanship_uninstall');

function sanship_activate() {}
function sanship_uninstall() {
    delete_option('sanship_client_id');
    delete_option('sanship_client_secret');
    delete_option('sanship_mode');
}
